
const sharp = require("sharp");
const aws = require("aws-sdk");
const s3 = new aws.S3();

const MAX_IMAGE_SIZE = 1000;
const JPEG_QUALITY = 80;
const JPEG_PROGRESSIVE = true;

exports.handler = async (event, context) => {
   if(event.Records[0].eventName === "ObjectRemoved:Delete") {
       return;
   }
   const BUCKET = event.Records[0].s3.bucket.name;
   const ORIGIN_KEY = event.Records[0].s3.object.key;

   const KEY_PROPERTIES = ORIGIN_KEY.split('/');

   if(
      KEY_PROPERTIES.length === 0 || 
      !KEY_PROPERTIES[1] || 
      KEY_PROPERTIES[0] !== "public" ||
      KEY_PROPERTIES[1] === "thumbnail" ||
      KEY_PROPERTIES[1] === "resized" ||
      KEY_PROPERTIES[1] === "img" ||
      KEY_PROPERTIES[1] === "temp" ||
      KEY_PROPERTIES[1] === "doc" ||
      KEY_PROPERTIES[1] === "data"
     ) {
    return;
   }



  // resize pictures placed in uploads foder (Import feature)
  if(KEY_PROPERTIES[1] == "uploads") {

    let fileName = KEY_PROPERTIES[2].split('.')?.[0] || KEY_PROPERTIES[2];
    fileName = `${fileName}.jpg`;
    const NEW_KEY = `public/${fileName}`;

    try {
      let image = await s3.getObject({ Bucket: BUCKET, Key: ORIGIN_KEY }).promise();
      image = await sharp(image.Body);
      const { width, height } = await image.metadata();

      let resizedImage;
      if (width <= MAX_IMAGE_SIZE && height <= MAX_IMAGE_SIZE && width === height) {
        resizedImage = await image.jpeg({ quality: JPEG_QUALITY, progressive: JPEG_PROGRESSIVE }).withMetadata().toBuffer();
      }
      if (width > height) {
        resizedImage = await image.resize({ width: MAX_IMAGE_SIZE }).jpeg({ quality: JPEG_QUALITY, progressive: JPEG_PROGRESSIVE }).withMetadata().toBuffer();
      }
      if (width < height) {
        resizedImage = await image.resize({ height: MAX_IMAGE_SIZE }).jpeg({ quality: JPEG_QUALITY, progressive: JPEG_PROGRESSIVE }).withMetadata().toBuffer();
      }

      await s3.putObject({ Bucket: BUCKET, Body: resizedImage, Key: NEW_KEY }).promise();
      await s3.deleteObject({ Bucket: BUCKET, Key: ORIGIN_KEY }).promise();
      return;
    }
    catch (err) {
      context.fail(`Error resizing image: ${err}`);
    }
    return;
  }

  if(KEY_PROPERTIES.length > 2) {
    console.log("LENGTH > 2", KEY_PROPERTIES)
    return;
  }
  
  // create thumbnail for pictures placed in public folder
  try {
    let fileName = KEY_PROPERTIES[1].split('.')?.[0] || KEY_PROPERTIES[1];
    fileName = `${fileName}.jpg`;
    const NEW_KEY = `public/thumbnail/${fileName}`;
  
    let image = await s3.getObject({ Bucket: BUCKET, Key: ORIGIN_KEY }).promise();
    image = await sharp(image.Body);
    
    const resizedImage = await image.resize({ width: 250, height: 250 }).jpeg({ quality: JPEG_QUALITY, progressive: JPEG_PROGRESSIVE }).withMetadata().toBuffer();
    await s3.putObject({ Bucket: BUCKET, Body: resizedImage, Key: NEW_KEY}).promise();
    return;

  }
  catch (err) {
    console.log("Error thumbnail")
    context.fail(`Error resizing image: ${err}`);
  }
  return;
};