/**
 * @type {import('@types/aws-lambda').APIGatewayProxyHandler}
 */
const aws = require('aws-sdk')
const ses = new aws.SES()

exports.handler = async (event) => {
  for (const streamedItem of event.Records) {
    if (streamedItem.eventName === 'INSERT' || streamedItem.eventName === 'UPDATE') {
      try {
        const { name, email, phone, storeEmail, message = { S: 'n/a'} } = streamedItem.dynamodb.NewImage
        await ses
          .sendEmail({
              Destination: {
                ToAddresses: [storeEmail.S],
              },
              Source: `"Skop" <about@skop.app>`,
              Message: {
              Subject: { Data: "[Boutique] Nouvelle demande d'information"},
                Body: {
                  Html: { Data: `<p>Bonjour,</p>
                  <p>Vous avez reçu une nouvelle demande d'information, consultez tous les détails depuis votre application ou Skop Manage.</p>
                  <ul>
                    <li>Nom: ${name.S}</li>
                    <li>Email: ${email.S}</li>
                    <li>Téléphone: ${phone.S}</li>
                    <li>Message: ${message.S}</li>
                  </ul>
                  <p><a href="https://manage.skop.app/">Skop</a></p>` 
                },
                  Text: { Data: `<p>Bonjour, 
                  Vous avez reçu une nouvelle demande d'information, consultez tous les détails depuis votre application ou Skop Manage. 
                  Nom: ${name.S} 
                  Email: ${email.S} 
                  Téléphone: ${phone.S} 
                  Message: ${message.S}
                  https://manage.skop.app/ ` },
                },
            },
        })
        .promise()
        return {
          statusCode: 200,
          message: JSON.stringify({ message: 'Email sent' })
        }
      } catch (error) {
        return {
          statusCode: 400,
          message: JSON.stringify({ error })
        }
      }
    }
  }
}