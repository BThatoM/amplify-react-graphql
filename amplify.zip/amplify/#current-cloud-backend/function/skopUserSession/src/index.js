/* Amplify Params - DO NOT EDIT
	API_LOOP_GRAPHQLAPIIDOUTPUT
	API_LOOP_USERSESSIONTABLE_ARN
	API_LOOP_USERSESSIONTABLE_NAME
	AUTH_LOOPPROJECT_USERPOOLID
	ENV
	REGION
Amplify Params - DO NOT EDIT */

/**
 * @type {import('@types/aws-lambda').APIGatewayProxyHandler}
 */

var aws = require('aws-sdk');
var ddb = new aws.DynamoDB({apiVersion: '2012-10-08'});

exports.handler = async (event, context) => {

    let date = new Date();

    const tableName = process.env.API_LOOP_USERSESSIONTABLE_NAME;
    const region = process.env.REGION;

    aws.config.update({region: region});

    if (event.request.userAttributes.sub) {
      console.log("request", event.request)
      console.log('context', context)
        let ddbParams = {
            Item: {
                'id': {S: context.awsRequestId},
                '__typename': {S: 'UserSession'},
                'userID': {S: event.request.userAttributes.sub},
                'newDevice': {BOOL: event.request.newDeviceUsed},
                'createdAt': {S: date.toISOString()},
                'updatedAt': {S: date.toISOString()},
                '_lastChangedAt': {N: date.getTime().toString()},
                '_version': {N: '0'},
            },
            TableName: tableName
        };
        try {
            await ddb.putItem(ddbParams).promise()
        } catch (err) {
            console.log("Error", err);
        }

        context.done(null, event);

    } else {
        console.log("Error: no userAttributes.sub");
        context.done(null, event);
    }
};
