/* Amplify Params - DO NOT EDIT
	API_LOOP_GRAPHQLAPIIDOUTPUT
	API_LOOP_USERTABLE_ARN
	API_LOOP_USERTABLE_NAME
	ENV
	REGION
Amplify Params - DO NOT EDIT */

var aws = require('aws-sdk');
var ddb = new aws.DynamoDB({apiVersion: '2012-10-08'});

exports.handler = async (event, context) => {

    let date = new Date();

    const tableName = process.env.TABLE_NAME;
    const region = process.env.REGION;

    aws.config.update({region: region});

    // If the required parameters are present, proceed
    if (event.request.userAttributes.sub) {

        // -- Write data to DDB
        let ddbParams = {
            Item: {
                'id': {S: event.request.userAttributes.sub},
                '__typename': {S: 'User'},
                'email': {S: event.request.userAttributes.email},
                'name': {S: event.request.userAttributes.name},
                'createdAt': {S: date.toISOString()},
                'updatedAt': {S: date.toISOString()},
                '_lastChangedAt': {N: date.getTime().toString()},
                '_version': {N: '0'},
            },
            TableName: tableName
        };

        // Call DynamoDB
        try {
            await ddb.putItem(ddbParams).promise()
        } catch (err) {
            console.log("Error", err);
        }

        context.done(null, event);

    } else {
        // Nothing to do, the user's email ID is unknown
        console.log("Error: Nothing was written to DDB");
        context.done(null, event);
    }
};