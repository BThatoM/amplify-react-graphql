

/**
 * @type {import('@types/aws-lambda').APIGatewayProxyHandler}
 */
 
 import { SESClient, SendTemplatedEmailCommand } from "@aws-sdk/client-ses";
 const sesClient = new SESClient({ region: "eu-central-1" });

 const createReminderEmailCommand = (email, organizationName, host, templateName) => {
  return new SendTemplatedEmailCommand({
    Source: `"Skop" <notification@skop.app>`,
    Template: templateName,
    Destination: {
      ToAddresses: [email],
    },
    TemplateData: JSON.stringify({
      subject: `Invitation à rejoindre ${organizationName} sur Skop`,
      title: "Invitation à rejoindre une équipe sur Skop",
      message: `Vous avez été invité par ${host} à rejoindre l'équipe ${organizationName} sur Skop pour participer à la gestion des ressources de l'organisation.`,
      ps: "Si vous ne souhaitez pas rejoindre cette équipe, vous pouvez ignorer cet email.",
      legal: ""
    }),
  });
};
 
 export const handler = async (event) => {
  for (const streamedItem of event.Records) {
    if (streamedItem.eventName === 'INSERT' || streamedItem.eventName === 'UPDATE') {
      try {
        const email = streamedItem.dynamodb.NewImage.email.S
        const { sendEmail, organizationName, host } = JSON.parse(streamedItem.dynamodb.NewImage.invitationDetails.S)

        if (!sendEmail) {
          return {
            statusCode: 200,
            message: JSON.stringify({ message: 'Email opt-out' })
          }
        }

        const sendReminderEmailCommand = createReminderEmailCommand(
          email,
          organizationName,
          host,
          "NotificationSkop"
        );

        await sesClient.send(sendReminderEmailCommand);
        
        return {
          statusCode: 200,
          message: JSON.stringify({ message: 'Email sent' })
        }
      } catch (error) {
        console.log({error})
        return {
          statusCode: 400,
          message: JSON.stringify({ error })
        }
      }
    }
  }
};